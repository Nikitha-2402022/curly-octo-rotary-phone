package com.leave.lams.exception;

@SuppressWarnings("serial")
public class ShiftSwapRequestNotFoundException  extends RuntimeException{
	public ShiftSwapRequestNotFoundException(String message) {
		super(message);
	}
}
